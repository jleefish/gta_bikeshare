var BikeApp = {

    Data:{
        stationList:null,
    },
    Views:{
        Home:{},
        Locations:{},
        Map:{},
        Reports:{}
    }
};

